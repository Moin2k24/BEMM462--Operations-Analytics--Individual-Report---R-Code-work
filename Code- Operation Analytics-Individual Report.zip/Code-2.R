library(Benchmarking)

# Input data: person-days, CPU time, risk level
x <- matrix(c(
  550, 200, 6,  # Project 1
  400, 150, 4,  # Project 2
  300, 400, 5,  # Project 3
  350, 450, 7,  # Project 4
  450, 300, 6,  # Project 5
  500, 150, 5,  # Project 6
  350, 200, 4,  # Project 7
  200, 600, 8   # Project 8
), ncol = 3, byrow = TRUE)

# Output data: profit, client satisfaction
y <- matrix(c(
  2.1, 8,  # Project 1
  0.5, 5,  # Project 2
  3.0, 9,  # Project 3
  2.0, 7,  # Project 4
  1.0, 6,  # Project 5
  1.5, 7,  # Project 6
  0.6, 5,  # Project 7
  1.8, 8   # Project 8
), ncol = 2, byrow = TRUE)

# Run input-oriented CRS DEA
dea_result <- dea(x, y, RTS = "crs", ORIENTATION = "in")

# Print efficiency scores
cat("Efficiency Scores:\n")
print(dea_result$eff)

# Identify efficient and inefficient projects
efficient <- which(dea_result$eff == 1)
inefficient <- which(dea_result$eff < 1)

cat("\nEfficient Projects:\n")
cat("Project", efficient, "\n")

cat("\nInefficient Projects:\n")
cat("Project", inefficient, "with efficiency scores:", dea_result$eff[inefficient], "\n")

# View peer projects (lambda values) for inefficient projects
cat("\nPeer Projects (Lambda Values):\n")
print(dea_result$lambda[inefficient, ]) 

