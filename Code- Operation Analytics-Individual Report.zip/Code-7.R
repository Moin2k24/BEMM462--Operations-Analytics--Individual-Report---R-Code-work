# Load the igraph package
library(igraph)

# Create the graph by defining edges and their profits (in million £)
edges <- c(
  1, 2, 1, 13, 2, 13, 13, 3, 3, 4, 4, 5, 4, 11, 5, 9, 9, 11, 9, 12,
  11, 12, 6, 9, 6, 12, 10, 12, 3, 11, 10, 9, 4, 7, 7, 9
)
profits <- c(
  27, 2, 4, 5, 8, 7, 3, 9, 3, 8,
  7, 3, 6, 15, 15, 6, 7, 9
)

# Create the graph
g <- graph(edges, n=13, directed=TRUE)
E(g)$weight <- profits

# Function to find the longest path in a DAG using topological sort and dynamic programming
longest_path_dag <- function(graph, start, end) {
  # Perform topological sort
  topo_order <- topo_sort(graph, mode="out")
  
  # Initialize distances (profits) and predecessors
  dist <- rep(-Inf, vcount(graph))
  dist[start] <- 0
  pred <- rep(NA, vcount(graph))
  
  # Process nodes in topological order
  for (node in topo_order) {
    if (dist[node] == -Inf) next  # Skip unreachable nodes
    
    # Get outgoing edges
    out_edges <- incident(graph, node, mode="out")
    if (length(out_edges) == 0) next
    
    # Update distances for neighbors
    for (edge in out_edges) {
      neighbor <- ends(graph, edge)[2]
      weight <- E(graph)$weight[edge]
      new_dist <- dist[node] + weight
      if (new_dist > dist[neighbor]) {
        dist[neighbor] <- new_dist
        pred[neighbor] <- node
      }
    }
  }
  
  # Reconstruct the path
  if (dist[end] == -Inf) {
    stop("No path exists from start to end node.")
  }
  
  path <- c()
  current <- end
  while (!is.na(current)) {
    path <- c(current, path)
    current <- pred[current]
  }
  
  list(path=path, profit=dist[end])
}

# Find the longest path from node 1 to node 12
result <- longest_path_dag(g, 1, 12)
path_nodes <- result$path
total_profit <- result$profit

# Print the sequence of the longest path (project sequence) and total profit
cat("Optimal project sequence to maximize profit from project 1 to project 12:\n")
cat(paste(path_nodes, collapse=" → "), "\n")
cat("Total expected profit (in million £):", total_profit, "\n")
