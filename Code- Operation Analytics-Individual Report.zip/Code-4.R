# Load package
library(lpSolve)

# Objective function (Factory 3 removed)
costs <- c(200, 500, 800, 400)  # x1s, x1i, x2s, x2i

# Constraint matrix
constraints <- matrix(c(
  # Steel demand
  1, 0, 1, 0,
  # Iron demand
  0, 1, 0, 1,
  # Factory 1 capacity
  1, 1, 0, 0,
  # Factory 2 capacity
  0, 0, 1, 1
), nrow=4, byrow=TRUE)

# RHS
rhs <- c(3200, 1000, 2000, 1500)

# Directions
directions <- c("=", "=", "<=", "<=")

# Solve LP
solution <- lp("min", costs, constraints, directions, rhs)

# Check feasibility
if (solution$status == 0) {
  x <- solution$solution
  cat("Optimal Demand Allocation (in tonnes):\n")
  cat("Factory 1 - Steel:", x[1], " Iron:", x[2], "\n")
  cat("Factory 2 - Steel:", x[3], " Iron:", x[4], "\n\n")
  cat("Minimum Total Shipping Cost (£):", solution$objval, "\n")
} else {
  cat("No feasible solution: Factories 1 and 2 cannot meet total demand without Factory 3.\n")
}
