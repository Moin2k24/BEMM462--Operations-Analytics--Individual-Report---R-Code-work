# Load package
library(lpSolve)

### --- Base Case: Shipping cost only ---
base_costs <- c(200, 500, 800, 400, 500, 1000)  # x1s, x1i, x2s, x2i, x3s, x3i

# Common constraint matrix
constraints <- matrix(c(
  1, 0, 1, 0, 1, 0,  # Steel demand
  0, 1, 0, 1, 0, 1,  # Iron demand
  1, 1, 0, 0, 0, 0,  # Factory 1 capacity
  0, 0, 1, 1, 0, 0,  # Factory 2 capacity
  0, 0, 0, 0, 1, 1   # Factory 3 capacity
), nrow=5, byrow=TRUE)

rhs <- c(3200, 1000, 2000, 1500, 2500)
directions <- c("=", "=", "<=", "<=", "<=")

# Solve base case
base_solution <- lp("min", base_costs, constraints, directions, rhs)
base_x <- base_solution$solution
base_cost <- base_solution$objval

### --- New Case: Shipping + Raw Material Cost ---
# Updated costs: Shipping + Raw material
new_costs <- c(250, 600, 870, 520, 545, 1130)
new_solution <- lp("min", new_costs, constraints, directions, rhs)
new_x <- new_solution$solution
new_cost <- new_solution$objval

### --- Compare Solutions ---
cat("Base Case Solution (Shipping only):\n")
cat("Factory 1 - Steel:", base_x[1], " Iron:", base_x[2], "\n")
cat("Factory 2 - Steel:", base_x[3], " Iron:", base_x[4], "\n")
cat("Factory 3 - Steel:", base_x[5], " Iron:", base_x[6], "\n")
cat("Total Shipping Cost (£):", base_cost, "\n\n")

cat("New Case Solution (Shipping + Raw Material):\n")
cat("Factory 1 - Steel:", new_x[1], " Iron:", new_x[2], "\n")
cat("Factory 2 - Steel:", new_x[3], " Iron:", new_x[4], "\n")
cat("Factory 3 - Steel:", new_x[5], " Iron:", new_x[6], "\n")
cat("Total Combined Cost (£):", new_cost, "\n\n")

### --- Check for Change ---
if (all(round(base_x, 2) == round(new_x, 2))) {
  cat("Conclusion: The optimal assignment plan has NOT changed.\n")
} else {
  cat("Conclusion: The optimal assignment plan HAS changed.\n")
  cat("Differences in assignment:\n")
  diff <- round(new_x - base_x, 2)
  names(diff) <- c("F1_Steel", "F1_Iron", "F2_Steel", "F2_Iron", "F3_Steel", "F3_Iron")
  print(diff)
}
