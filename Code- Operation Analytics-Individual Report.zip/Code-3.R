# Load package
library(lpSolve)

# Objective function coefficients (shipping costs only)
costs <- c(200, 500, 800, 400, 500, 1000)  # x1s, x1i, x2s, x2i, x3s, x3i

# Constraint matrix
constraints <- matrix(c(
  # Steel demand
  1, 0, 1, 0, 1, 0,
  # Iron demand
  0, 1, 0, 1, 0, 1,
  # Factory 1 capacity
  1, 1, 0, 0, 0, 0,
  # Factory 2 capacity
  0, 0, 1, 1, 0, 0,
  # Factory 3 capacity
  0, 0, 0, 0, 1, 1
), nrow=5, byrow=TRUE)

# Right-hand side of constraints
rhs <- c(3200, 1000, 2000, 1500, 2500)

# Constraint directions
directions <- c("=", "=", "<=", "<=", "<=")

# Solve LP
solution <- lp("min", costs, constraints, directions, rhs)

# Extract solution
x <- solution$solution

# Print individual assignments
cat("Steel and Iron Shipment Plan (in tonnes):\n")
cat("Factory 1 - Steel:", x[1], " Iron:", x[2], "\n")
cat("Factory 2 - Steel:", x[3], " Iron:", x[4], "\n")
cat("Factory 3 - Steel:", x[5], " Iron:", x[6], "\n\n")

# Print minimum cost
cat("Minimum Shipping Cost (£):", solution$objval, "\n")
