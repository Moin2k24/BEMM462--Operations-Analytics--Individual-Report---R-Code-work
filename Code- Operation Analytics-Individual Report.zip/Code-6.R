# Load the igraph package
library(igraph)
# Create the graph by defining edges and their weights
edges <- c(
  1, 2, 1, 13, 2, 13, 13, 3, 3, 4, 4, 5, 4, 11, 5, 9, 9, 11, 9, 12,
  11, 12, 6, 9, 6, 12, 10, 12, 3, 11, 10, 9, 4, 7, 7, 9
)
weights <- c(
  27, 2, 4, 5, 8, 7, 3, 9, 3, 8,
  7, 3, 6, 15, 15, 6, 7, 9
)

# Create the graph
g <- graph(edges, n=13, directed=TRUE)
E(g)$weight <- weights

# Find the shortest path from node 1 to node 12 using Dijkstra's algorithm
shortest_path <- shortest_paths(g, from=1, to=12, weights=E(g)$weight, output="both")

# Extract the path and total cost
path <- shortest_path$vpath[[1]]
path_nodes <- as.numeric(V(g)[path]$name)
total_cost <- shortest_path$epath[[1]]
total_cost_value <- sum(E(g)[total_cost]$weight)

# Print the sequence of the shortest path in the console
cat("Sequence of the shortest path from influencer 1 to influencer 12:\n")
cat(paste(path_nodes, collapse=" → "), "\n")
cat("Total cost of the path:", total_cost_value, "\n")
