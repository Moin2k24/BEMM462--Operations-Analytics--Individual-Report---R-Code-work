 
library(Benchmarking)

# Step 2: Input the data
# Inputs: person-days, CPU time (hours)
# Output: profit (in million £)
x <- matrix(c(
  550, 200,  # Project 1: person-days, CPU time
  400, 150,  # Project 2
  300, 400,  # Project 3
  350, 450,  # Project 4
  450, 300,  # Project 5
  500, 150,  # Project 6
  350, 200,  # Project 7
  200, 600   # Project 8
), ncol = 2, byrow = TRUE)

y <- matrix(c(
  2.1,  # Project 1: profit
  0.5,  # Project 2
  3.0,  # Project 3
  2.0,  # Project 4
  1.0,  # Project 5
  1.5,  # Project 6
  0.6,  # Project 7
  1.8   # Project 8
), ncol = 1)

# Step 3: Run input-oriented CRS DEA
dea_result <- dea(x, y, RTS = "crs", ORIENTATION = "in")

# Step 4: Print efficiency scores
cat("Efficiency Scores:\n")
print(dea_result$eff)

# Step 5: Identify efficient and inefficient projects
efficient <- which(dea_result$eff == 1)
inefficient <- which(dea_result$eff < 1)

cat("\nEfficient Projects:\n")
cat("Project", efficient, "\n")

cat("\nInefficient Projects:\n")
cat("Project", inefficient, "with efficiency scores:", dea_result$eff[inefficient], "\n")

# Step 6: Optional - View peer projects (lambda values) for inefficient projects
cat("Peer Projects (Lambda Values):\n")
print(dea_result$lambda[inefficient, ])
